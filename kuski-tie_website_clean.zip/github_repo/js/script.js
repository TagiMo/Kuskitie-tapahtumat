// Load events from JSON file
let events = [];
let filteredEvents = [];

document.addEventListener('DOMContentLoaded', function() {
    // Fetch the events data
    fetch('event_data/april_events.json')
        .then(response => response.json())
        .then(data => {
            events = data;
            filteredEvents = [...events];
            displayEvents(filteredEvents);
            setupFilters();
            updateEventCount();
        })
        .catch(error => {
            console.error('Error loading events:', error);
            document.querySelector('.loading').innerHTML = '<p>Virhe tapahtumien lataamisessa. Yritä päivittää sivu.</p>';
        });
});

function displayEvents(eventsToShow) {
    const eventGrid = document.getElementById('event-grid');
    
    // Remove loading spinner
    const loadingElement = document.querySelector('.loading');
    if (loadingElement) {
        eventGrid.removeChild(loadingElement);
    }
    
    // Clear existing events
    while (eventGrid.firstChild) {
        eventGrid.removeChild(eventGrid.firstChild);
    }

    if (eventsToShow.length === 0) {
        const noEvents = document.createElement('div');
        noEvents.className = 'no-events';
        noEvents.textContent = 'Ei tapahtumia valituilla hakuehdoilla.';
        eventGrid.appendChild(noEvents);
        return;
    }

    eventsToShow.forEach(event => {
        const eventCard = document.createElement('div');
        eventCard.className = 'event-card';
        eventCard.setAttribute('data-category', event.category);
        eventCard.setAttribute('data-potential', event.potential);
        eventCard.setAttribute('data-date', event.date);

        eventCard.innerHTML = `
            <div class="event-header">
                <h3>${event.name}</h3>
                <div class="event-date">${event.date} klo ${event.time}</div>
            </div>
            <div class="event-details">
                <div class="detail-item">
                    <span class="label">Paikka:</span>
                    <span class="value">${event.venue}</span>
                </div>
                <div class="detail-item">
                    <span class="label">Osoite:</span>
                    <span class="value">${event.address}</span>
                </div>
                <div class="detail-item">
                    <span class="label">Kategoria:</span>
                    <span class="value category-tag ${event.category}">${getCategoryName(event.category)}</span>
                </div>
                <div class="detail-item">
                    <span class="label">Asiakaspotentiaali:</span>
                    <span class="value">${getStars(event.potential)}</span>
                </div>
                <div class="detail-item">
                    <span class="label">Paras saapumisaika:</span>
                    <span class="value">${event.bestArrivalTime}</span>
                </div>
            </div>
            <div class="event-actions">
                <button class="btn-more" onclick="showEventDetails('${encodeURIComponent(JSON.stringify(event))}')">Lisätietoja</button>
                <button class="btn-favorite" onclick="toggleFavorite(this)"><i class="far fa-heart"></i></button>
            </div>
        `;

        eventGrid.appendChild(eventCard);
    });
}

function getStars(potential) {
    let stars = '';
    for (let i = 0; i < 5; i++) {
        if (i < potential) {
            stars += '<i class="fas fa-star"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    return stars;
}

function getCategoryName(category) {
    const categories = {
        'urheilu': 'Urheilu',
        'kulttuuri': 'Kulttuuri',
        'yoelama': 'Yöelämä',
        'liikenne': 'Liikenne',
        'markkinat': 'Markkinat',
        'perhe': 'Perhe',
        'seminaari': 'Seminaari',
        'ruoka': 'Ruoka',
        'muu': 'Muu'
    };
    return categories[category] || category;
}

function setupFilters() {
    // Date filter buttons
    const dateFilterButtons = document.querySelectorAll('.filter-button[data-filter]');
    dateFilterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all date filter buttons
            dateFilterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            applyFilters();
        });
    });

    // Category filter buttons
    const categoryFilterButtons = document.querySelectorAll('.filter-button[data-category]');
    categoryFilterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all category filter buttons
            categoryFilterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            applyFilters();
        });
    });

    // Potential filter buttons
    const potentialFilterButtons = document.querySelectorAll('.filter-button[data-potential]');
    potentialFilterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all potential filter buttons
            potentialFilterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            applyFilters();
        });
    });

    // Search input
    const searchInput = document.getElementById('search-input');
    searchInput.addEventListener('input', function() {
        applyFilters();
    });

    // Search button
    const searchButton = document.getElementById('search-button');
    searchButton.addEventListener('click', function() {
        applyFilters();
    });
}

function applyFilters() {
    // Get filter values
    const dateFilter = document.querySelector('.filter-button[data-filter].active').getAttribute('data-filter');
    const categoryFilter = document.querySelector('.filter-button[data-category].active').getAttribute('data-category');
    const potentialFilter = document.querySelector('.filter-button[data-potential].active').getAttribute('data-potential');
    const searchValue = document.getElementById('search-input').value.toLowerCase();

    // Filter events
    filteredEvents = events.filter(event => {
        // Date filter
        if (dateFilter !== 'all') {
            const eventDate = parseEventDate(event.date);
            const today = new Date();
            
            if (dateFilter === 'upcoming') {
                if (eventDate < today) return false;
            } else if (dateFilter === 'today') {
                if (!isSameDay(eventDate, today)) return false;
            } else if (dateFilter === 'week') {
                const nextWeek = new Date(today);
                nextWeek.setDate(today.getDate() + 7);
                if (eventDate < today || eventDate > nextWeek) return false;
            } else if (dateFilter === 'month') {
                // Already filtered for April
            }
        }

        // Category filter
        if (categoryFilter !== 'all' && event.category !== categoryFilter) return false;

        // Potential filter
        if (potentialFilter !== 'all' && event.potential < parseInt(potentialFilter)) return false;

        // Search filter
        if (searchValue && 
            !event.name.toLowerCase().includes(searchValue) && 
            !event.venue.toLowerCase().includes(searchValue) &&
            !event.address.toLowerCase().includes(searchValue)) return false;

        return true;
    });

    // Display filtered events
    displayEvents(filteredEvents);
    updateEventCount();
}

function updateEventCount() {
    const countElement = document.getElementById('event-count');
    countElement.textContent = filteredEvents.length;
}

function parseEventDate(dateStr) {
    const parts = dateStr.split('.');
    // Note: months are 0-indexed in JavaScript Date
    return new Date(parseInt('2025'), parseInt(parts[1]) - 1, parseInt(parts[0]));
}

function isSameDay(date1, date2) {
    return date1.getDate() === date2.getDate() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getFullYear() === date2.getFullYear();
}

function showEventDetails(eventJson) {
    const event = JSON.parse(decodeURIComponent(eventJson));
    
    const modal = document.getElementById('event-modal');
    const modalContent = document.querySelector('.modal-content');
    
    modalContent.innerHTML = `
        <span class="close-modal" onclick="closeModal()">&times;</span>
        <h2>${event.name}</h2>
        <div class="modal-event-details">
            <p><i class="fas fa-calendar"></i> ${event.date}</p>
            <p><i class="fas fa-clock"></i> ${event.time}</p>
            <p><i class="fas fa-map-marker-alt"></i> ${event.venue}</p>
            <p><i class="fas fa-location-arrow"></i> ${event.address}</p>
            <div class="customer-potential">
                <p>Asiakaspotentiaali:</p>
                <div class="stars">
                    ${getStars(event.potential)}
                </div>
            </div>
            <div class="best-arrival-time">
                <p>Paras saapumisaika:</p>
                <p class="arrival-time">${event.bestArrivalTime}</p>
            </div>
            <div class="weather-forecast">
                <h3>Sääennuste</h3>
                <p><i class="fas fa-cloud-sun"></i> Tarkista sää tapahtumapäivälle</p>
            </div>
            <div class="traffic-info">
                <h3>Liikennetilanne</h3>
                <p><i class="fas fa-car"></i> Tarkista liikennetilanne ennen lähtöä</p>
            </div>
        </div>
        <div class="modal-actions">
            <button class="add-to-favorites" onclick="addToFavorites(this)"><i class="far fa-heart"></i> Lisää suosikkeihin</button>
            <button class="share-event" onclick="shareEvent()"><i class="fas fa-share-alt"></i> Jaa tapahtuma</button>
        </div>
    `;
    
    modal.style.display = 'block';
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target === modal) {
            closeModal();
        }
    };
}

function closeModal() {
    const modal = document.getElementById('event-modal');
    modal.style.display = 'none';
}

function addToFavorites(button) {
    button.innerHTML = '<i class="fas fa-heart"></i> Lisätty suosikkeihin';
    button.classList.add('favorited');
    showNotification('Tapahtuma lisätty suosikkeihin!');
}

function toggleFavorite(button) {
    const icon = button.querySelector('i');
    if (icon.classList.contains('far')) {
        icon.classList.remove('far');
        icon.classList.add('fas');
        showNotification('Tapahtuma lisätty suosikkeihin!');
    } else {
        icon.classList.remove('fas');
        icon.classList.add('far');
        showNotification('Tapahtuma poistettu suosikeista!');
    }
}

function shareEvent() {
    showNotification('Jakamistoiminto ei ole vielä käytössä');
}

function showNotification(message) {
    // Remove any existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => {
        document.body.removeChild(notification);
    });
    
    // Create new notification
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Hide and remove notification
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}
